import 'source-map-support/register';
import { APIGatewayProxyHandler } from 'aws-lambda';
export declare const handler: APIGatewayProxyHandler;
//# sourceMappingURL=getByDocument.d.ts.map