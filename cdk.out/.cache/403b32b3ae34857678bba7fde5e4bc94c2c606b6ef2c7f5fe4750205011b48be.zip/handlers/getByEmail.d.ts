import 'source-map-support/register';
import { APIGatewayProxyHandler } from 'aws-lambda';
export declare const handler: APIGatewayProxyHandler;
//# sourceMappingURL=getByEmail.d.ts.map