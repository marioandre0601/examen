import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { CustomerRepo } from "./customer-repo";
export declare function getCustomerRepo(ddb_client: DynamoDBClient): CustomerRepo;
//# sourceMappingURL=index.d.ts.map